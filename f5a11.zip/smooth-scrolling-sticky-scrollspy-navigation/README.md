# Smooth Scrolling Sticky ScrollSpy Navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/bramus/pen/ExaEqMJ](https://codepen.io/bramus/pen/ExaEqMJ).

